import { AuthSession, clearSession, getStoredSession, logoutRoleAccount, storeSession } from "@/lib/api";

export type PortalRole = "admin" | "supercoordinator" | "volunteer" | "coordinator";

export const ROLE_COLLECTION = "roleAccounts";

export interface RoleAccount {
  id: string;
  name: string;
  email: string;
  role: PortalRole;
  department?: string;
  assignedSport?: string;
  assignedSportId?: string;
  assignedSportName?: string;
}

export const roleHomePath: Record<PortalRole, string> = {
  admin: "/admin-dashboard",
  supercoordinator: "/admin",
  volunteer: "/volunteer-dashboard",
  coordinator: "/coordinator-dashboard",
};

export function getRoleAccount(): RoleAccount | null {
  const session = getStoredSession();
  if (!session) return null;

  return {
    id: session.id,
    name: session.name,
    email: session.email,
    role: session.role,
    department: session.department,
    assignedSport: session.assignedSport,
    assignedSportId: session.assignedSportId,
    assignedSportName: session.assignedSportName,
  };
}

export function storePortalSession(session: AuthSession) {
  storeSession(session);
}

export function clearPortalSession() {
  clearSession();
}

export async function logoutPortalSession() {
  await logoutRoleAccount();
}

export function canAccessRole(accountRole: PortalRole, requiredRole: PortalRole) {
  return accountRole === "admin" || accountRole === "supercoordinator" || accountRole === requiredRole;
}
